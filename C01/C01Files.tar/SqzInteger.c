/** CS 2505 Fall 2017:  SqzInteger.c
 * 
 *  Supplied framework for squeezing out digits project.  Your task is to
 *  complete the supplied code to satisfy the posted specification for this
 *  assignment.  
 * 
 *  Student:   <ENTER YOUR NAME HERE>
 *  PID:       <ENTER YOUR VT EMAIL PID HERE>
 */
#include "SqzInteger.h"

/**  Computes a new integer from N by removing all the even (or odd)
 *   digits from N; if no digits remain, the function computes 0.
 * 
 * Pre:  N is initialized
 *       Action is EVEN or ODD
 * Returns:  integer obtained by removing all EVEN (or all ODD) digits
 *           from N; 0 if no digits of N remain
 *
 * Restrictions:
 *   - uses only its parameters and local automatic variables
 *   - does not make any use of character variables or arrays
 *   - does not read input or write output
 *   - does not use math.h
 */
uint32_t SqzInteger(uint32_t N, enum ProcessChoice Action) {

   uint32_t Squeezed = 0;

   // You need to  implement the computation of Squeezed
   
   return Squeezed;
}

