#include "word.h"

//unscrambles a clear problem, returning the unscrambled Word_List
struct Word_List unscrambleClear(FILE* dataFile);

//unscrambles a fuzzy problem, returning the unscrambled Word_List
struct Word_List unscrambleFuzzy(FILE* dataFile);